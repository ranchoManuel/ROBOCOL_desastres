#ifndef MAIN_H
#define MAIN_H

void imprimirEnConsola(char *texto);

#endif
