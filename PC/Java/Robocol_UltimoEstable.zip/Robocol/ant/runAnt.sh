#Instalarlo en caso de que no este en la maquina.
#sudo apt-get install ant
ant -buildfile armarAplicacion.xml
