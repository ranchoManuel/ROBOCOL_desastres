package mundo;

public interface IComunicacion
{
	public void enviarLinea(String linea);
	public void close();
}